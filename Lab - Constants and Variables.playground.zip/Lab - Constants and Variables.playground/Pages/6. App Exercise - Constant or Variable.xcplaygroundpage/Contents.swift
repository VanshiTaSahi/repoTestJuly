/*:
## App Exercise - Fitness Tracker: Constant or Variable?
 
 >These exercises reinforce Swift concepts in the context of a fitness tracking app.
 
 There are all sorts of things that a fitness tracking app needs to keep track of in order to display the right information to the user. Similar to the last exercise, declare either a constant or a variable for each of the following items, and assign each a sensible value. Be sure to use proper naming conventions.
 
- Name: The user's name
- Age: The user's age
- Number of steps taken today: The number of steps that a user has taken today
- Goal number of steps: The user's goal for number of steps to take each day
- Average heart rate: The user's average heart rate over the last 24 hours
 */
let name: String = "Vanshita"
print("I used let for name as name of the person will remain constant")
var age: Int = 21
print("I used var as every passing year age will change and will be upated")
var stepsTaken :Int = 950099
print("I used var as number of steps taken change every passing minute so it won't be constant")
let goalSteps :Int = 1000000
print("I used let because goalSteps for they day will be constant as we set a goal that we want achieve so that would be constant")
let avareageRate :Int = 72
print("I used let because avarageRate will come out be constant as diff values of heart rate in last 24 hrs are calculated and at the end average is taken so that will be constant for all given values")

/*:
 Now go back and add a line after each constant or variable declaration. On those lines, print a statement explaining why you chose to declare the piece of information as a constant or variable.
 
[Previous](@previous)  |  page 6 of 10  |  [Next: Exercise - Types and Type Safety](@next)
 */
